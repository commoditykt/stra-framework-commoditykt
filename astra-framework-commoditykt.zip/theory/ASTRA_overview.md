## ASTRA Overview

ASTRA is a framework for analyzing chaotic systems by focusing on global vector sums such as total velocity. It detects quasi-periodicity through time-series rhythm analysis.