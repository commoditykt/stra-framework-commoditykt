## Phase Resonance Notes

Cross-lagged correlations between velocity components suggest synchronized behavior across axes in three-body simulations.