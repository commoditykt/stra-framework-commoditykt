# ASTRA Framework: Aggregated Systemic Time-Series Rhythm Analysis

This repository is a joint project between Kim Kyungtae and Crystalline to explore chaotic systems using total-velocity-based rhythm analysis.