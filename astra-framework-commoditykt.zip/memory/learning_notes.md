## Learning Notes

- Three-body system overview
- Total velocity vector time series
- ACF and FFT reveal emergent structure
- Cross-lagged correlation implies internal rhythm
